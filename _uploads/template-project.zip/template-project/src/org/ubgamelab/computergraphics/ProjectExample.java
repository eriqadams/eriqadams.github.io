package org.ubgamelab.computergraphics;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.util.glu.GLU.*;

import org.lwjgl.input.*;
import org.ubgamelab.computergraphics.util.*;

public class ProjectExample extends CGApplication {
	@Override
	public void init() {

	}

	@Override
	public void update(int delta) {
	}

	@Override
	public void render() {
		glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	}

	@Override
	public void deinit() {

	}

	public static void main(String[] args) {
		CGApplication app = new ProjectExample();
		app.start(800, 600, false, false, true,
				"Computer Graphics Course : Project Template Example.");
	}

}
